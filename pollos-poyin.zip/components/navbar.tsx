"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"
import Image from "next/image"

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="bg-amber-900 text-white sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Image
            src="/placeholder.svg?height=40&width=40"
            alt="Pollos Poyin Logo"
            width={40}
            height={40}
            className="rounded-full"
          />
          <span className="text-xl font-bold text-amber-100">Pollos Poyin</span>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex space-x-6">
          <a href="#inicio" className="hover:text-amber-300 transition-colors">
            Inicio
          </a>
          <a href="#menu" className="hover:text-amber-300 transition-colors">
            Menú
          </a>
          <a href="#ubicacion" className="hover:text-amber-300 transition-colors">
            Ubicación
          </a>
          <a href="#contacto" className="hover:text-amber-300 transition-colors">
            Contacto
          </a>
        </div>

        {/* Mobile Navigation Button */}
        <button className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation Menu */}
      {isOpen && (
        <div className="md:hidden bg-amber-800 py-4">
          <div className="container mx-auto px-4 flex flex-col space-y-3">
            <a
              href="#inicio"
              className="text-white hover:text-amber-300 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Inicio
            </a>
            <a
              href="#menu"
              className="text-white hover:text-amber-300 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Menú
            </a>
            <a
              href="#ubicacion"
              className="text-white hover:text-amber-300 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Ubicación
            </a>
            <a
              href="#contacto"
              className="text-white hover:text-amber-300 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Contacto
            </a>
          </div>
        </div>
      )}
    </nav>
  )
}

