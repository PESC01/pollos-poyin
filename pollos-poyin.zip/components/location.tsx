import { MapPin, Clock, Phone } from "lucide-react"
import AnimatedSection from "@/components/animated-section"

export default function Location() {
  return (
    <section id="ubicacion" className="py-16 bg-amber-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-amber-900 mb-4">Nuestra Ubicación</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Visítanos y disfruta de la mejor experiencia gastronómica
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <AnimatedSection direction="left">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold text-amber-900 mb-4">Información de Contacto</h3>

              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <MapPin className="text-amber-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Dirección</h4>
                    <p className="text-gray-600">Av. Principal 123, Ciudad</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Clock className="text-amber-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Horario de Atención</h4>
                    <p className="text-gray-600">Lunes a Domingo: 11:00 AM - 10:00 PM</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Phone className="text-amber-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Teléfono</h4>
                    <p className="text-gray-600">+51 123 456 789</p>
                  </div>
                </div>
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection direction="right" delay={0.2}>
            <div className="h-[400px] rounded-lg overflow-hidden shadow-lg">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3901.964663061!2d-77.03196492394376!3d-12.046656888118893!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9105c8b5d35662c7%3A0x15f0bbc54bcbe432!2sPlaza%20Mayor%20de%20Lima!5e0!3m2!1ses!2spe!4v1710259560314!5m2!1ses!2spe"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Ubicación de Pollos Poyin"
              ></iframe>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  )
}

