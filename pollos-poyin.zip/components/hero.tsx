"use client"

import { Button } from "@/components/ui/button"
import AnimatedSection from "@/components/animated-section"

export default function Hero() {
  return (
    <section id="inicio" className="relative h-[80vh] flex items-center">
      <div
        className="absolute inset-0 bg-cover bg-center z-0"
        style={{
          backgroundImage: "url('/placeholder.svg?height=1080&width=1920')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-black/50"></div>
      </div>

      <div className="container mx-auto px-4 z-10 relative">
        <AnimatedSection direction="up">
          <div className="max-w-2xl text-white">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">El mejor pollo a la brasa</h1>
            <p className="text-xl md:text-2xl mb-8">
              Disfruta del sabor inigualable de nuestro pollo a la brasa, preparado con nuestra receta secreta y los
              mejores ingredientes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-amber-600 hover:bg-amber-700 text-white"
                onClick={() => document.getElementById("menu")?.scrollIntoView({ behavior: "smooth" })}
              >
                Ver Menú
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white/10"
                onClick={() => window.open("https://wa.me/1234567890", "_blank")}
              >
                Ordenar Ahora
              </Button>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}

