"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import AnimatedSection from "@/components/animated-section"

// Menu data
const menuItems = [
  {
    id: 1,
    name: "Menú Económico",
    description: "1/8 de pollo con papas fritas y ensalada",
    price: "S/. 12.90",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 2,
    name: "Cuarto de Pollo",
    description: "1/4 de pollo con papas fritas, ensalada y ají",
    price: "S/. 18.90",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 3,
    name: "Medio Pollo",
    description: "1/2 pollo con papas fritas, ensalada y ají",
    price: "S/. 32.90",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQypvv5lce6QVSWAnNfQm6GZqpIuRENXRquWw&s",
  },
  {
    id: 4,
    name: "Pollo Entero",
    description: "Pollo entero con papas fritas, ensalada y ají",
    price: "S/. 59.90",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0SJZ2lmulTdlUJjfwXWuawrk8QPKIN_5e6A&s",
  },
  {
    id: 5,
    name: "Milanesa de Pollo",
    description: "Filete de pollo empanizado con papas y ensalada",
    price: "S/. 22.90",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 6,
    name: "Milanesa de Carne",
    description: "Filete de carne empanizado con papas y ensalada",
    price: "S/. 24.90",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 7,
    name: "Pipoca de Pollo",
    description: "Trozos de pollo crocante con papas y salsas",
    price: "S/. 19.90",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 8,
    name: "Alitas de Pollo",
    description: "Alitas bañadas en salsa BBQ o picante",
    price: "S/. 25.90",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 9,
    name: "Postres Variados",
    description: "Consulta nuestros postres del día",
    price: "Desde S/. 8.90",
    image: "/placeholder.svg?height=300&width=400",
  },
]

export default function Menu() {
  const openWhatsApp = (item: string) => {
    const message = `Hola, me gustaría ordenar: ${item}`
    window.open(`https://wa.me/1234567890?text=${encodeURIComponent(message)}`, "_blank")
  }

  return (
    <section id="menu" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-amber-900 mb-4">Nuestro Menú</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Disfruta de nuestras deliciosas especialidades preparadas con los mejores ingredientes
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {menuItems.map((item, index) => (
            <AnimatedSection key={item.id} delay={(index * 0.1) % 0.5}>
              <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-2 group">
                <div className="relative h-64 w-full">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.name}
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-amber-900">{item.name}</CardTitle>
                  <CardDescription>{item.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-xl font-bold text-amber-700">{item.price}</p>
                </CardContent>
                <CardFooter>
                  <Button
                    className="w-full bg-amber-600 hover:bg-amber-700 transition-all duration-300 group-hover:bg-amber-500"
                    onClick={() => openWhatsApp(item.name)}
                  >
                    Ordenar Ahora
                  </Button>
                </CardFooter>
              </Card>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}

